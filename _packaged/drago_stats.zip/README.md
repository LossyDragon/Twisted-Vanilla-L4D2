# [L4D2] hx_stats

MySQL Stats for Left 4 Dead 1 & 2 (Co-op)

Requirements
• MySQL: External connections required if your MySQL server is not on the same system ! This is not enabled by default, you may need to contact your host!
• Metamod: Source/SourceMM (Latest Version)
• SourceMod: 1.10 or newer builds

Installation
• Edit your configs/databases.cfg file and add a section with the following information:

"l4d2_stats"
{ 
    "driver"              "mysql"
    "host"                "your_host"
    "database"            "your_db"
    "user"                "your_user"
    "pass"                "your_pass"
}  
