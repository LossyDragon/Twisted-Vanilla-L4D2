#include "extension.h"
#include "GeoIP.h"
#include "GeoIPCity.h"

GeoIPCity g_GeoIPCity;
SMEXT_LINK(&g_GeoIPCity);

GeoIP *gi = NULL;

bool GeoIPCity::SDK_OnLoad(char *error, size_t maxlength, bool late)
{
	char path[PLATFORM_MAX_PATH];

	g_pSM->BuildPath(Path_SM, path, sizeof(path), "configs/geoip/GeoIPCity.dat");

	// http://www.maxmind.com/app/benchmark
	gi = GeoIP_open(path, GEOIP_MEMORY_CACHE);

	if (!gi)
	{
		snprintf(error, maxlength, "Failed to open: %s", path);
		return false;
	}

	GeoIP_set_charset(gi, GEOIP_CHARSET_UTF8);

	g_pShareSys->AddNatives(myself, geoipcity_natives);
	g_pShareSys->RegisterLibrary(myself, "GeoIPCity");
	g_pSM->LogMessage(myself, "GeoIPCity database info: %s", GeoIP_database_info(gi));

	return true;
}

void GeoIPCity::SDK_OnUnload()
{
	GeoIP_delete(gi);
	gi = NULL;
}

/*******************************
*                              *
* GEOIP NATIVE IMPLEMENTATIONS *
*                              *
*******************************/

inline void StripPort(char *ip)
{
	char *tmp = strchr(ip, ':');
	if (!tmp)
		return;
	*tmp = '\0';
}

static cell_t sm_Geoip_Get_Record(IPluginContext *pCtx, const cell_t *params)
{
	if (!gi)
	{
		return pCtx->ThrowNativeError("GeoIPCity database not loaded.");
	}

	char *ip;

	// Grab the IP and strip the port
	pCtx->LocalToString(params[1], &ip);
	StripPort(ip);

	// Retrive the matching record in the database
	GeoIPRecord *gir = GeoIP_record_by_addr(gi, ip);

	if (!gir)
		return 0; // No record found.

	// Expose the data to SourceMod
	const char *region = GeoIP_region_name_by_code(gir->country_code, gir->region);

	pCtx->StringToLocalUTF8(params[2], 45, gir->city ? gir->city : "", NULL);
	pCtx->StringToLocalUTF8(params[3], 45, region ? region : "", NULL);
	pCtx->StringToLocalUTF8(params[4], 45, gir->country_name ? gir->country_name : "", NULL);
	pCtx->StringToLocalUTF8(params[5], 3, gir->country_code ? gir->country_code : "", NULL);
	pCtx->StringToLocalUTF8(params[6], 4, gir->country_code3 ? gir->country_code3 : "", NULL);

	GeoIPRecord_delete(gir);

	return 1;
}

const sp_nativeinfo_t geoipcity_natives[] = 
{
	{"GeoipGetRecord",		sm_Geoip_Get_Record},
	{NULL,					NULL},
};
