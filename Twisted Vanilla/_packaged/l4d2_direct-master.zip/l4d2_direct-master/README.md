l4d2_direct
===========

This project aims to expose Director and other variables to sourcepawn scripters.

Previously this sort of work was done through left4downtown2, but since Sourcemod 1.4 direct address reads and writes are available directly through sourcepawn.

Ideally, l4d2_direct will provide a simple API for reading and writing to the various CDirector classes, ZombieManager, TerrorNavMesh, and other useful classes.

Code is released under GPLv3 as with every other SourcePawn project.
