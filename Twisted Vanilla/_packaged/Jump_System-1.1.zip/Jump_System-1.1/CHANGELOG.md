# Changelog

## Version 1.1 (February 1, 2022)

### Changes

#### Game Data
- L4D1: Updated an offset for the `1.0.4.1` game update.

## Version 1.0 (January 28, 2022)

Initial Release.